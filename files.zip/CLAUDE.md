# Project: [Your App Name] — Global Instructions

## Tech Stack

- **Frontend**: React JS, Redux (Redux Toolkit), React Router
- **Backend**: Node.js (Express)
- **ORM**: TypeORM
- **Database**: MariaDB
- **Quality**: SonarQube (≥90% coverage, zero code smells), Veracode (SAST)

---

## Codebase Orientation

Before writing any code, read the existing codebase:

1. Read `package.json` to understand installed versions and scripts
2. Read `src/common/` to understand shared components, hooks, and utilities
3. Read `src/components/` to understand custom/reusable UI components
4. Read `src/store/` to understand Redux slices and store structure
5. Read `src/api/` or `server/` to understand API layer conventions
6. Read existing entity files in `src/entities/` before creating new ones
7. Never duplicate what already exists — reuse common components and utilities

---

## Folder Structure

```
project-root/
├── src/
│   ├── common/              # Shared utilities, hooks, HOCs, constants
│   │   ├── components/      # Truly generic UI (Button, Input, Modal, Table)
│   │   ├── hooks/           # Shared custom hooks
│   │   ├── utils/           # Pure utility functions
│   │   └── constants/       # App-wide constants and enums
│   ├── components/          # Feature-adjacent reusable components
│   ├── features/            # Feature modules (one folder per feature)
│   │   └── [feature-name]/
│   │       ├── components/  # Feature-specific UI
│   │       ├── hooks/       # Feature-specific hooks
│   │       ├── slice.ts     # Redux slice
│   │       ├── selectors.ts
│   │       ├── types.ts
│   │       └── [Feature].test.tsx
│   ├── store/               # Redux store setup, root reducer
│   ├── api/                 # Axios instances, interceptors, API utilities
│   └── pages/               # Route-level page components
├── server/
│   ├── controllers/
│   ├── services/
│   ├── entities/            # TypeORM entities
│   ├── migrations/
│   ├── middleware/
│   └── routes/
├── .claude/
│   └── rules/               # Feature-specific Claude rule files
└── CLAUDE.md                # This file
```

Always place new files in the correct folder. Ask if location is unclear.

---

## Component Usage Rules

- **Always prefer `src/common/components/`** for generic UI needs (buttons, modals, tables, forms, inputs)
- **Never create a new generic component** if one exists — extend via props instead
- **Feature-specific components** go in `src/features/[feature]/components/`
- **Check `src/components/`** for mid-level reusable components before creating new ones
- Import paths: use absolute imports via `@/` alias, never deep relative paths (`../../../`)

---

## Global Coding Standards

### React / Frontend
- Functional components only — no class components
- Always type props with TypeScript interfaces (not `any`)
- Co-locate component, styles, and tests in the same folder
- Use `React.memo` only when profiling shows re-render issues
- All async state must go through Redux slices, not local `useState`
- Handle loading, error, and empty states for every async operation

### Redux
- Use Redux Toolkit (`createSlice`, `createAsyncThunk`) — no raw reducers
- Keep selectors in `selectors.ts`, not inline in components
- Never mutate state outside of a slice reducer
- Normalize data in the store for list entities

### Node.js / Backend
- All database access through TypeORM repositories — no raw SQL unless in migrations
- Controllers are thin — logic lives in services
- All routes must have input validation middleware
- Use async/await with try-catch — no unhandled promise rejections
- Return consistent error response shapes: `{ message, code, details? }`

### TypeORM / MariaDB
- Always write migrations for schema changes — never sync in production
- Use transactions for multi-step writes
- Add indexes for all foreign keys and frequently queried columns
- Entity relations must be explicitly defined with cascade rules

---

## Quality Gates (Non-Negotiable)

### SonarQube

Every PR must pass:
- **Coverage**: ≥ 90% line and branch coverage
- **Code smells**: Zero new code smells introduced
- **Duplications**: No duplicated code blocks
- **Cognitive complexity**: Functions must stay below complexity threshold (default 15)

Rules when writing code:
- Every function/method needs a corresponding unit test
- Test both happy path AND all error branches
- Mock external dependencies (DB, API calls, file system) in tests
- Use `describe` blocks to group related tests
- Write tests before or alongside the code, not after

Coverage minimums per file type:
- Services: 95%
- Utils/helpers: 100%
- Controllers: 85%
- React components: 85% (use React Testing Library)
- Redux slices: 95%

### Veracode (SAST Security Scan)

Never introduce:
- SQL injection risk — always use TypeORM parameterized queries
- XSS vulnerabilities — sanitize all user input before rendering
- Hardcoded secrets — use environment variables via `process.env`
- Insecure deserialization — validate all incoming JSON
- Path traversal — validate and sanitize all file path inputs
- Weak cryptography — use bcrypt for passwords, never MD5/SHA1
- IDOR — always verify resource ownership before returning data
- Unvalidated redirects — whitelist redirect targets

Security checklist before any PR:
- [ ] No `console.log` with sensitive data
- [ ] No hardcoded credentials, tokens, or API keys
- [ ] All user inputs validated and sanitized
- [ ] Auth checks on all protected endpoints
- [ ] Error messages don't leak internal stack traces

---

## Testing Standards

```
// File naming
[ComponentName].test.tsx     // React component tests
[serviceName].test.ts        // Service unit tests
[featureName].integration.test.ts  // Integration tests

// Test structure
describe('[FeatureName]', () => {
  describe('[functionOrComponent]', () => {
    it('should [expected behaviour] when [condition]', () => { ... });
    it('should handle [error case]', () => { ... });
  });
});
```

- Use `jest` + `@testing-library/react` for frontend
- Use `jest` + `supertest` for backend route testing
- Mock with `jest.mock()` — never mock the module under test
- Reset mocks in `beforeEach` or `afterEach`

---

## Feature Development Workflow

When starting a new feature:

1. Create `.claude/rules/features/[feature-name].md` using the template at `.claude/rules/features/_TEMPLATE.md`
2. Define the feature's scope, API contracts, data model, and component tree in that file
3. Read the feature rule file before writing any code for that feature
4. Follow the conventions defined in the feature rule file throughout development

---

## Git Conventions

- Branch: `feature/[ticket-id]-short-description`
- Commit: `[type]([scope]): message` — types: `feat`, `fix`, `test`, `refactor`, `chore`
- Never commit directly to `main` or `develop`
- Every commit must leave tests passing

---

## What Claude Should Never Do

- Never skip writing tests to "save time"
- Never use `any` type in TypeScript
- Never write raw SQL in controllers or services
- Never add `// TODO` comments and leave them — either implement or open a ticket
- Never create a new component when an existing one can be extended
- Never commit environment variables or secrets
- Never introduce a new dependency without checking if existing deps solve the problem
