---
paths:
  - "server/**"
  - "src/api/**"
---

# Veracode Security Rules

Veracode performs static analysis (SAST) on every build. These rules prevent scan failures.
CWE references are included — Veracode reports use CWE IDs.

---

## Input Validation (CWE-20)

All user-supplied data must be validated before use.

```typescript
// ✅ Use a validation library consistently
import { IsString, IsEmail, Length } from 'class-validator';

class CreateUserDto {
  @IsEmail()
  email: string;

  @IsString()
  @Length(8, 128)
  password: string;
}

// ✅ Validate in controller middleware before hitting the service
router.post('/users', validateDto(CreateUserDto), userController.create);
```

Never trust:
- `req.body` fields without schema validation
- URL parameters without type coercion and bounds checking
- Query strings used in database queries

---

## SQL Injection (CWE-89)

Always use TypeORM's query builder or repository methods. Never build SQL strings.

```typescript
// ❌ Veracode WILL flag this
const users = await db.query(`SELECT * FROM user WHERE email = '${email}'`);

// ✅ TypeORM parameterized — safe
const users = await userRepository.findOne({ where: { email } });

// ✅ Query builder with parameters
const users = await userRepository
  .createQueryBuilder('user')
  .where('user.email = :email', { email })
  .getMany();
```

---

## XSS (CWE-79)

```typescript
// ❌ Never inject unescaped user content into JSX or HTML
<div dangerouslySetInnerHTML={{ __html: userInput }} />

// ✅ Always render user content as text, never HTML
<div>{userInput}</div>

// ✅ If HTML is required (rich text), sanitize first
import DOMPurify from 'dompurify';
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(richText) }} />
```

---

## Sensitive Data Exposure (CWE-200, CWE-312)

```typescript
// ❌ Never hardcode secrets
const apiKey = 'sk-prod-abc123xyz';

// ✅ Always use environment variables
const apiKey = process.env.EXTERNAL_API_KEY;

// ❌ Never log sensitive fields
console.log('User login:', { email, password });

// ✅ Log only safe identifiers
logger.info('User login attempt', { userId: user.id });

// ❌ Never return passwords or tokens in API responses
return { id, email, password, token }; // includes sensitive fields

// ✅ Explicitly select safe fields
return { id, email, createdAt };
```

Password handling:

```typescript
import bcrypt from 'bcrypt';
const SALT_ROUNDS = 12;

// Hash on create/update
const hashed = await bcrypt.hash(plainPassword, SALT_ROUNDS);

// Compare on login
const match = await bcrypt.compare(plainPassword, storedHash);
```

---

## IDOR — Insecure Direct Object Reference (CWE-639)

Always verify ownership before returning or modifying a resource.

```typescript
// ❌ Trusts the request parameter — any user can access any record
async getReport(reportId: string) {
  return reportRepository.findOne({ where: { id: reportId } });
}

// ✅ Scopes query to authenticated user
async getReport(reportId: string, requestingUserId: string) {
  const report = await reportRepository.findOne({
    where: { id: reportId, userId: requestingUserId }
  });
  if (!report) throw new ForbiddenException();
  return report;
}
```

---

## Path Traversal (CWE-22)

```typescript
import path from 'path';

// ❌ Direct use of user-supplied filename
const filePath = `./uploads/${req.body.filename}`;

// ✅ Sanitize and resolve within allowed base directory
const UPLOAD_DIR = path.resolve('./uploads');
const requested = path.resolve(UPLOAD_DIR, path.basename(req.body.filename));

if (!requested.startsWith(UPLOAD_DIR)) {
  throw new BadRequestException('Invalid file path');
}
```

---

## Authentication & Authorization (CWE-287, CWE-285)

- Every protected route must have authentication middleware applied
- JWT tokens must use RS256 or HS256 with a secret ≥ 32 characters
- Token expiry must be set — never use non-expiring tokens
- Refresh tokens must be stored server-side and rotatable

```typescript
// ✅ Route protection pattern
router.get('/reports', authenticate, authorize('reports:read'), reportController.list);
```

---

## Error Handling — No Information Leakage (CWE-209)

```typescript
// ❌ Stack traces reach the client
app.use((err, req, res, next) => {
  res.status(500).json({ error: err.stack });
});

// ✅ Generic message to client, full detail to server logs only
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error('Unhandled error', { err, path: req.path });
  res.status(500).json({ message: 'An unexpected error occurred' });
});
```

---

## Veracode Pre-Scan Checklist

Before every build that triggers a Veracode scan:

- [ ] No hardcoded credentials, secrets, or API keys
- [ ] All DB queries use parameterized TypeORM methods
- [ ] All `req.body` fields validated via DTO before use
- [ ] No `dangerouslySetInnerHTML` without DOMPurify
- [ ] All protected routes have auth middleware
- [ ] Ownership checks on all resource access
- [ ] Error handler returns generic messages (not stack traces)
- [ ] No `console.log` in production paths with user data
