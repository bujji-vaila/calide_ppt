---
paths:
  - "src/**"
  - "server/**"
---

# SonarQube Quality Rules

## Coverage Requirements

| Layer              | Min Line Coverage | Min Branch Coverage |
|--------------------|-------------------|---------------------|
| Services           | 95%               | 95%                 |
| Utils / helpers    | 100%              | 100%                |
| Controllers        | 85%               | 80%                 |
| React components   | 85%               | 80%                 |
| Redux slices       | 95%               | 90%                 |
| Middleware         | 90%               | 85%                 |

Every PR must maintain or improve the overall project coverage. Never merge a PR that drops coverage below 90%.

---

## Zero Code Smell Policy

### Functions

- Max lines per function: **30**
- Max parameters per function: **4** (use an options object if more are needed)
- Cognitive complexity score per function: **≤ 15**
- No dead code — unused variables, imports, and functions must be removed

### Naming

- No single-character variable names outside loop counters
- Boolean variables and functions must use `is`, `has`, `can`, `should` prefix
- No abbreviations unless universally understood (`id`, `url`, `api`, `db`)

### Duplication

- No copy-pasted logic blocks longer than 5 lines — extract to a shared function
- No near-duplicate components — parameterize differences with props

---

## Test Quality Rules

### What Tests Must Cover

Every function needs tests for:
- ✅ Happy path (valid inputs, expected output)
- ✅ Edge cases (empty arrays, zero, null, boundary values)
- ✅ Error cases (invalid input, thrown exceptions, rejected promises)
- ✅ All branches of conditional logic (`if/else`, `switch`, ternaries)

### Test Anti-Patterns (Sonar Flags These)

```typescript
// ❌ Empty test body — Sonar flags as test without assertion
it('should work', () => {});

// ❌ Test without assertion
it('should call the service', () => {
  service.doSomething();
  // no expect — Sonar flags this
});

// ❌ Overlapping test data — not testing independently
// ✅ Use beforeEach to reset state between tests

// ❌ Catching and swallowing test errors
try {
  await service.doSomething();
} catch (e) {
  // ignored — never do this in tests
}
```

### React Component Test Pattern

```typescript
// ✅ Correct pattern for React Testing Library
import { render, screen, userEvent } from '@testing-library/react';
import { renderWithProviders } from '@/test-utils'; // wraps with Redux/Router

describe('ComponentName', () => {
  it('should render correctly', () => {
    renderWithProviders(<ComponentName prop="value" />);
    expect(screen.getByRole('button', { name: /submit/i })).toBeInTheDocument();
  });

  it('should handle user interaction', async () => {
    const user = userEvent.setup();
    renderWithProviders(<ComponentName />);
    await user.click(screen.getByRole('button'));
    expect(screen.getByText(/success/i)).toBeInTheDocument();
  });
});
```

### Service Test Pattern

```typescript
describe('UserService', () => {
  let service: UserService;
  let mockRepository: jest.Mocked<Repository<User>>;

  beforeEach(() => {
    mockRepository = createMockRepository<User>();
    service = new UserService(mockRepository);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('findById', () => {
    it('should return user when found', async () => {
      mockRepository.findOne.mockResolvedValue(mockUser);
      const result = await service.findById('123');
      expect(result).toEqual(mockUser);
    });

    it('should throw NotFoundException when user does not exist', async () => {
      mockRepository.findOne.mockResolvedValue(null);
      await expect(service.findById('999')).rejects.toThrow(NotFoundException);
    });
  });
});
```

---

## Running Sonar Locally

Before pushing, run:

```bash
npm run test:coverage          # generate coverage report
npm run sonar                  # run sonar-scanner locally (if configured)
```

Check `coverage/lcov-report/index.html` for uncovered lines before opening a PR.
