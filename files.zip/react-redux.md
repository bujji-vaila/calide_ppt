---
paths:
  - "src/**"
---

# React & Redux Conventions

## Component Structure

Every component file follows this order:

```typescript
// 1. Imports (external → internal → types → styles)
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Button } from '@/common/components/Button';
import { useFeatureData } from './hooks/useFeatureData';
import { fetchItems, selectItems } from './slice';
import type { ItemProps } from './types';

// 2. Types
interface Props {
  featureId: string;
  onSuccess?: () => void;
}

// 3. Component
export const FeatureComponent: React.FC<Props> = ({ featureId, onSuccess }) => {
  // 3a. Redux
  const dispatch = useDispatch();
  const items = useSelector(selectItems);

  // 3b. Local state (use sparingly — prefer Redux for async state)
  const [isOpen, setIsOpen] = useState(false);

  // 3c. Custom hooks
  const { data, isLoading } = useFeatureData(featureId);

  // 3d. Effects
  useEffect(() => {
    dispatch(fetchItems(featureId));
  }, [featureId, dispatch]);

  // 3e. Handlers
  const handleSubmit = () => {
    // ...
    onSuccess?.();
  };

  // 3f. Render guards
  if (isLoading) return <Spinner />;
  if (!data) return <EmptyState />;

  // 3g. Render
  return (
    <div>
      <Button onClick={handleSubmit}>Submit</Button>
    </div>
  );
};
```

---

## Redux Slice Pattern

```typescript
// slice.ts
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import type { Item, FeatureState } from './types';
import { featureApi } from '@/api/featureApi';

const initialState: FeatureState = {
  items: [],
  selectedId: null,
  status: 'idle',   // 'idle' | 'loading' | 'succeeded' | 'failed'
  error: null,
};

export const fetchItems = createAsyncThunk(
  'feature/fetchItems',
  async (featureId: string, { rejectWithValue }) => {
    try {
      return await featureApi.getItems(featureId);
    } catch (err) {
      return rejectWithValue((err as Error).message);
    }
  }
);

export const featureSlice = createSlice({
  name: 'feature',
  initialState,
  reducers: {
    setSelectedId(state, action: PayloadAction<string>) {
      state.selectedId = action.payload;
    },
    clearError(state) {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchItems.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(fetchItems.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.items = action.payload;
      })
      .addCase(fetchItems.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload as string;
      });
  },
});

export const { setSelectedId, clearError } = featureSlice.actions;
export default featureSlice.reducer;
```

---

## Selectors Pattern

```typescript
// selectors.ts — always memoize derived data with createSelector
import { createSelector } from '@reduxjs/toolkit';
import type { RootState } from '@/store';

const selectFeatureState = (state: RootState) => state.feature;

export const selectItems = createSelector(
  selectFeatureState,
  (feature) => feature.items
);

export const selectIsLoading = createSelector(
  selectFeatureState,
  (feature) => feature.status === 'loading'
);

export const selectActiveItem = createSelector(
  selectFeatureState,
  (feature) => feature.items.find(i => i.id === feature.selectedId) ?? null
);
```

---

## Common Component Usage

Always check `src/common/components/` before creating UI. Key available components:

| Component     | Use For                              | Import                                    |
|---------------|--------------------------------------|-------------------------------------------|
| `Button`      | All clickable actions                | `@/common/components/Button`              |
| `Input`       | Text inputs, search                  | `@/common/components/Input`               |
| `Modal`       | Dialogs, confirmations               | `@/common/components/Modal`               |
| `Table`       | Data grids                           | `@/common/components/Table`               |
| `Spinner`     | Loading states                       | `@/common/components/Spinner`             |
| `EmptyState`  | No-data views                        | `@/common/components/EmptyState`          |
| `ErrorBanner` | Error display                        | `@/common/components/ErrorBanner`         |
| `FormField`   | Labelled form field wrapper          | `@/common/components/FormField`           |

When extending a common component, add a prop — do not fork it.

---

## API Layer Pattern

```typescript
// src/api/featureApi.ts
import { apiClient } from '@/api/client';  // configured Axios instance
import type { Item } from '@/features/feature/types';

export const featureApi = {
  getItems: (featureId: string) =>
    apiClient.get<Item[]>(`/features/${featureId}/items`).then(r => r.data),

  createItem: (featureId: string, data: CreateItemPayload) =>
    apiClient.post<Item>(`/features/${featureId}/items`, data).then(r => r.data),
};
```

Never call `axios` directly inside components or slices. Always go through the API layer.
