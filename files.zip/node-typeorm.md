---
paths:
  - "server/**"
---

# Node.js & TypeORM Conventions

## Request Lifecycle

```
Request → Router → Validation Middleware → Auth Middleware → Controller → Service → Repository → DB
```

- **Router**: wires paths to controller methods + applies middleware
- **Validation Middleware**: validates and transforms `req.body` using DTOs
- **Auth Middleware**: verifies JWT, attaches `req.user`
- **Controller**: extracts params, calls service, sends response
- **Service**: business logic, orchestrates repositories
- **Repository**: TypeORM data access only

---

## Controller Pattern

Controllers are thin. No business logic, no direct DB calls.

```typescript
// controllers/itemController.ts
import { Request, Response, NextFunction } from 'express';
import { ItemService } from '@/services/ItemService';
import { CreateItemDto } from '@/dtos/item.dto';

export class ItemController {
  constructor(private readonly itemService: ItemService) {}

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const dto = req.body as CreateItemDto;  // already validated by middleware
      const item = await this.itemService.create(dto, req.user.id);
      return res.status(201).json(item);
    } catch (err) {
      next(err);  // delegate to error handler
    }
  }

  async findById(req: Request, res: Response, next: NextFunction) {
    try {
      const item = await this.itemService.findById(req.params.id, req.user.id);
      return res.json(item);
    } catch (err) {
      next(err);
    }
  }
}
```

---

## Service Pattern

```typescript
// services/ItemService.ts
import { Repository } from 'typeorm';
import { Item } from '@/entities/Item';
import { CreateItemDto } from '@/dtos/item.dto';
import { NotFoundException, ForbiddenException } from '@/common/errors';

export class ItemService {
  constructor(private readonly itemRepository: Repository<Item>) {}

  async create(dto: CreateItemDto, userId: string): Promise<Item> {
    const item = this.itemRepository.create({ ...dto, userId });
    return this.itemRepository.save(item);
  }

  async findById(id: string, requestingUserId: string): Promise<Item> {
    const item = await this.itemRepository.findOne({ where: { id } });

    if (!item) throw new NotFoundException(`Item ${id} not found`);

    // IDOR check — always scope to requesting user
    if (item.userId !== requestingUserId) throw new ForbiddenException();

    return item;
  }
}
```

---

## TypeORM Entity Pattern

```typescript
// entities/Item.ts
import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn,
  ManyToOne, JoinColumn, Index
} from 'typeorm';
import { User } from './User';

@Entity('item')
export class Item {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 255 })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string | null;

  @Column({ name: 'is_active', type: 'boolean', default: true })
  isActive: boolean;

  @Index()
  @Column({ name: 'user_id', type: 'uuid' })
  userId: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: User;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
```

Rules:
- Column names use `snake_case` in the DB, `camelCase` in the entity
- Always define `onDelete` on `ManyToOne` relations
- Add `@Index()` on all foreign key columns and frequently queried columns
- Use `uuid` for primary keys, not auto-increment integers

---

## Migration Pattern

Always generate migrations for schema changes. Never use `synchronize: true` in production.

```bash
# Generate migration from entity changes
npm run typeorm migration:generate -- -n AddItemDescriptionColumn

# Run migrations
npm run typeorm migration:run
```

Migration file naming: `[timestamp]-[PascalCaseDescription].ts`

---

## Transaction Pattern

Use transactions for multi-step writes that must be atomic.

```typescript
async transferItem(itemId: string, toUserId: string): Promise<void> {
  await this.dataSource.transaction(async (manager) => {
    const item = await manager.findOne(Item, { where: { id: itemId } });
    if (!item) throw new NotFoundException();

    const audit = manager.create(AuditLog, {
      action: 'TRANSFER',
      entityId: itemId,
      fromUserId: item.userId,
      toUserId,
    });

    item.userId = toUserId;

    await manager.save(item);
    await manager.save(audit);
  });
}
```

---

## Error Response Standard

All errors must conform to:

```typescript
// common/errors.ts
export class AppError extends Error {
  constructor(
    public readonly message: string,
    public readonly code: string,
    public readonly statusCode: number
  ) {
    super(message);
  }
}

export class NotFoundException extends AppError {
  constructor(msg = 'Resource not found') {
    super(msg, 'NOT_FOUND', 404);
  }
}

export class ForbiddenException extends AppError {
  constructor(msg = 'Access denied') {
    super(msg, 'FORBIDDEN', 403);
  }
}

export class ValidationException extends AppError {
  constructor(public readonly details: string[]) {
    super('Validation failed', 'VALIDATION_ERROR', 400);
  }
}
```

Response shape:
```json
{ "message": "Resource not found", "code": "NOT_FOUND" }
{ "message": "Validation failed", "code": "VALIDATION_ERROR", "details": ["email is required"] }
```
