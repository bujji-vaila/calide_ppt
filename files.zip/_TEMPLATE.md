# Feature Rule: [Feature Name]

> Copy this file to `.claude/rules/features/[feature-name].md` when starting a new feature.
> Fill in every section before writing any code. Claude reads this file for the entire feature.

---

## Feature Overview

**Ticket / Story**: [PROJ-123]
**Description**: [One paragraph — what this feature does, why it exists, who uses it]
**Scope**: [What is IN scope and what is explicitly OUT of scope]

---

## Folder Structure for This Feature

```
src/features/[feature-name]/
├── components/
│   ├── [FeatureName].tsx          # Main feature component
│   ├── [FeatureName]Form.tsx      # (if form involved)
│   └── [FeatureName]List.tsx      # (if list involved)
├── hooks/
│   └── use[FeatureName].ts        # Data-fetching hook
├── slice.ts                       # Redux slice
├── selectors.ts                   # Memoized selectors
├── types.ts                       # Feature-specific types
├── [feature-name].test.tsx        # Component tests
└── [feature-name].service.test.ts # Service tests (if applicable)

server/
├── controllers/[featureName]Controller.ts
├── services/[featureName]Service.ts
├── entities/[FeatureName].ts        # (if new entity)
├── dtos/[featureName].dto.ts
└── routes/[featureName].routes.ts
```

---

## Data Model

### New Entities (if any)

```typescript
// Describe the entity shape here before creating the entity file
interface [EntityName] {
  id: string;            // uuid PK
  // ... add fields
  userId: string;        // FK to User
  createdAt: Date;
  updatedAt: Date;
}
```

### Existing Entities Modified (if any)

- `[EntityName]`: adding column `[columnName]` — requires migration
- `[EntityName]`: adding relation to `[OtherEntity]`

### Required Migrations

- [ ] `[timestamp]-Add[ColumnName]To[TableName]`

---

## API Contracts

### Endpoints

| Method | Path                             | Auth | Description             |
|--------|----------------------------------|------|-------------------------|
| GET    | `/api/[feature]`                 | JWT  | List items              |
| GET    | `/api/[feature]/:id`             | JWT  | Get single item         |
| POST   | `/api/[feature]`                 | JWT  | Create item             |
| PUT    | `/api/[feature]/:id`             | JWT  | Update item             |
| DELETE | `/api/[feature]/:id`             | JWT  | Soft-delete item        |

### Request DTO

```typescript
// dtos/[featureName].dto.ts
class Create[Feature]Dto {
  @IsString()
  @Length(1, 255)
  name: string;

  // ... add validation decorators for each field
}
```

### Response Shape

```typescript
// Exact response shape the API returns
interface [Feature]Response {
  id: string;
  name: string;
  // ...
  createdAt: string; // ISO 8601
}
```

### Error Cases

| Scenario                      | HTTP Status | Code                  |
|-------------------------------|-------------|-----------------------|
| Item not found                | 404         | `NOT_FOUND`           |
| User does not own the item    | 403         | `FORBIDDEN`           |
| Validation failure            | 400         | `VALIDATION_ERROR`    |

---

## Redux State Shape

```typescript
// types.ts
interface [Feature]State {
  items: [Feature][];
  selectedId: string | null;
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}
```

### Async Thunks Needed

- `fetch[Feature]s(filters)` — load list
- `fetch[Feature]ById(id)` — load single
- `create[Feature](dto)` — create
- `update[Feature]({ id, dto })` — update
- `delete[Feature](id)` — delete

---

## Component Tree

```
[FeatureName]Page (route-level)
└── [FeatureName]List
    ├── [FeatureName]ListItem (repeated)
    └── [FeatureName]EmptyState
[FeatureName]Modal (dialog for create/edit)
└── [FeatureName]Form
    ├── [uses common] FormField
    ├── [uses common] Input
    └── [uses common] Button
```

### Reusing Common Components

List the common components this feature will use (check `src/common/components/` first):

- `Button` — for all CTA actions
- `Modal` — for create/edit dialog
- `Table` — for list display
- `FormField` — for all form inputs
- [ ] Add others as identified during development

---

## Business Logic Rules

Document the domain-specific rules Claude must enforce throughout this feature:

1. [Rule 1 — e.g. "An item can only be edited by its owner"]
2. [Rule 2 — e.g. "Status can only transition: draft → active → archived"]
3. [Rule 3 — e.g. "Deletion is soft-delete only — set deletedAt timestamp"]
4. ...

---

## Test Plan

### Unit Tests Required

- [ ] `[featureName]Service.test.ts` — all service methods (create, read, update, delete, error paths)
- [ ] `[featureName]Slice.test.ts` — all reducers and thunk states (pending/fulfilled/rejected)
- [ ] `[featureName]Selectors.test.ts` — all selectors
- [ ] `[FeatureName]Form.test.tsx` — form validation, submission, error display
- [ ] `[FeatureName]List.test.tsx` — rendering, empty state, loading state

### Integration Tests

- [ ] Full CRUD flow via API endpoints (using supertest)
- [ ] Auth enforcement — unauthenticated requests return 401
- [ ] IDOR enforcement — user A cannot access user B's resources

### Coverage Target

This feature must reach **≥ 90% line and branch coverage** before PR.

---

## Security Checklist (Veracode)

Specific checks for this feature:

- [ ] All `req.body` fields for this feature's endpoints are validated via DTO
- [ ] Every endpoint that returns a user-owned resource checks ownership
- [ ] No hardcoded values for [list any feature-specific sensitive config]
- [ ] [Any other feature-specific security consideration]

---

## Acceptance Criteria

Define "done" for this feature:

- [ ] [AC 1]
- [ ] [AC 2]
- [ ] [AC 3]
- [ ] All SonarQube checks pass (≥90% coverage, 0 code smells)
- [ ] Veracode scan passes with no new findings
- [ ] PR reviewed and approved
